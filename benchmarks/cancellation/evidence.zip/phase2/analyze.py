import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
rows = []
probe_hashes = set()
runner_hashes = set()
for output in sorted((root/'study').iterdir()):
    if not output.is_dir() or not (output/'summary.json').exists():
        continue
    meta = json.loads((output/'metadata.json').read_text())
    summary = json.loads((output/'summary.json').read_text())
    with (output/'events.tsv').open() as stream:
        events = list(csv.DictReader(stream, delimiter='\t'))
    def select(event, role):
        return [e for e in events if e['event'] == event and e['role'] == role]
    def values(event, role):
        return [int(e['value']) for e in select(event, role)]
    assert sorted(values('partition_rows', 'warmup-long')) == [8000000,8000000], output
    assert values('partition_rows','warmup-short') == [1], output
    assert values('partition_checksum','warmup-short') == [49995000], output
    checksum = 0
    for value in values('partition_checksum','warmup-long'):
        checksum ^= value
    assert checksum == 170321032354260451, output
    row = dict(case=output.name,variant=meta['artifact_manifest']['variant'],
               engine=meta['arguments']['engine'],
               trace=meta['arguments']['trace'],delay_ms=int(meta['arguments']['delay_ms']),**summary)
    if row['mode'] == 'complete':
        assert sorted(values('partition_rows','long')) == [8000000,8000000], output
        assert len(select('driver_success','long')) == 1, output
        checksum = 0
        for value in values('partition_checksum','long'):
            checksum ^= value
        assert checksum == 170321032354260451, output
    if row['mode'] != 'cancel-alone':
        assert values('partition_rows','short') == [1], output
        assert values('partition_checksum','short') == [49995000], output
        row['short_submit_to_executor_entry_ms'] = (int(select('task_enter','short')[0]['nano_time'])-int(select('submit','short')[0]['nano_time']))/1e6
    row['long_partition_rows'] = values('partition_rows','long')
    row['long_first_row_count'] = len(select('first_row','long'))
    row['warmup_long_consumer_span_ms'] = (max(int(e['nano_time']) for e in select('task_completion','warmup-long'))-min(int(e['nano_time']) for e in select('task_enter','warmup-long')))/1e6
    if select('cancel_request','long'):
        trigger = int(select('cancel_request','long')[0]['nano_time'])
        last_end = max(int(e['nano_time']) for e in select('task_end_finish_epoch_ms','long'))
        with (output/'samples.tsv').open() as stream:
            samples = list(csv.DictReader(stream, delimiter='\t'))
        before = [s for s in samples if int(s['nano_time']) <= trigger][-1]
        after = [s for s in samples if int(s['nano_time']) >= last_end][0]
        row['process_cpu_seconds_bracketing_cancel_to_task_end'] = (int(after['process_cpu_ns'])-int(before['process_cpu_ns']))/1e9
        row['cpu_bracket_seconds'] = (int(after['nano_time'])-int(before['nano_time']))/1e9
        if (output/'lifecycle.tsv').exists():
            with (output/'lifecycle.tsv').open() as stream:
                row['lifecycle_after_cancel'] = [dict(plan=e['plan'],phase=e['phase'],after_cancel_ms=(int(e['nano_time'])-trigger)/1e6) for e in csv.DictReader(stream,delimiter='\t') if int(e['nano_time'])>=trigger]
    probe_hashes.add(meta['probe_source_sha256'])
    runner_hashes.add(meta['runner_source_sha256'])
    rows.append(row)
assert len(probe_hashes)==1, probe_hashes
assert len(runner_hashes)==1, runner_hashes
(root/'comparison.json').write_text(json.dumps(dict(probe_hashes=sorted(probe_hashes),runner_hashes=sorted(runner_hashes),runs=rows),indent=2)+'\n')
for row in rows:
    print(row['case'], 'last_end_ms',round(row['trigger_to_last_long_task_end_observed_ms'],3), 'short_launch_ms',round(row.get('short_submit_to_first_task_launch_observed_ms',0),3), 'long_rows',row['long_partition_rows'])
