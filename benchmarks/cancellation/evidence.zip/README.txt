Cancellation / task-slot admission evidence
Base: apache/datafusion-comet c4a0b1f2bce44ffa2bbeab3bbc1f715853734969

Nothing in this archive has been submitted upstream. The prototype is experimental.
Requires Python 3.11+ and JDK 21. Builds and measurements here used Spark 4.1.3.

To reproduce the original unchanged-engine baseline, use a fresh checkout at the
base commit and apply cancellation-reproducer.patch. Follow the added README:
  git apply /path/to/cancellation-reproducer.patch
  cargo build --manifest-path native/Cargo.toml --release
  ./mvnw -B test-compile dependency:build-classpath -Dmdep.outputFile=target/cancellation-classpath.txt -Dmdep.includeScope=test -DskipTests
  python3 benchmarks/cancellation/run.py prepare /scratch/data /scratch/prepare --rows 16000000
  python3 benchmarks/cancellation/run.py run /scratch/data /scratch/baseline --rows 16000000
  python3 benchmarks/cancellation/run.py run /scratch/data /scratch/spark --engine spark --rows 16000000

To reproduce phase 2, use another fresh checkout at the base commit. Apply
phase2/probe.patch, then either batch-production.patch or native-production.patch
from phase2/. Do not apply both production patches: native includes batch checks.
Build and run the same commands. Add --trace only for a separate diagnostic run.
The optional phase2/jvm-tests.patch applies to the native prototype only.

baseline/study contains the original 14 runs and monotonic corrected summaries.
phase2/study contains the 13 later runs, all using one newer common probe. Cases
01-06 are trace-off cancellation comparisons; 07-08 complete normally; 09 cancels
without a short task; 10-13 enable trace. Case 13 cancels at 1000 ms after both
consumers enter; other cancellation cases use 200 ms. Phase 2's probe retains
memory sampling contexts until TaskEnd, including native task-completion cleanup.

The original and phase-2 probe source hashes differ; each round is internally
consistent. phase2/artifacts holds manifests and source patches, not binaries.
Their hashes identify the local builds and are not expected to match a rebuild
on a different machine. The 3.9 GiB data and compiled binaries are not included.

Task launch/end durations use monotonic listener receipt times. cancel_ack is a
JVM marker after a native cancellation call returns; release_return is after a
native release call returns. Neither measures exact native compute stop or
physical memory reuse. Process CPU and memory counters are process/accounting
observations. These are constructed saturated-slot cases, not natural-workload
frequency measurements or latency bounds. Normal-query overhead is unmeasured.

phase2/analyze.py rebuilds comparison.json from the extracted phase2/study data.
SHA256SUMS lists the uncompressed archive entries other than SHA256SUMS itself.
